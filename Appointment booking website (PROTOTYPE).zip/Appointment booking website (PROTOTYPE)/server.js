const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = 5000;
const SECRET_KEY = 'dhanus';

// Middleware
app.use(bodyParser.json());
app.use(cors());

// MongoDB connection

mongoose.connect('mongodb+srv://221501502:dd%40221501502@cluster0.yxnxj.mongodb.net/', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('MongoDB connected successfully'))
  .catch((err) => console.log('MongoDB connection error: ', err));


const db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
  console.log('Connected to MongoDB');
});

// User Schema and Model
const userSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
  role: String, // Added role field
});

userSchema.pre('save', async function (next) {
  const user = this;
  if (!user.isModified('password')) return next();
  user.password = await bcrypt.hash(user.password, 8);
  next();
});

const User = mongoose.model('User', userSchema);

// Appointment Schema and Model
const appointmentSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  name: String,
  email: String,
  date: Date,
  desc: String,
});

const Appointment = mongoose.model('Appointment', appointmentSchema);

// Routes
// Registration
app.post('/register', async (req, res) => {
  const { username, email, password, role } = req.body; // Destructure role from request body
  const user = new User({ username, email, password, role }); // Include role when creating new user
  await user.save();
  res.send(user);
});

// Login
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(400).send('User not found');

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) return res.status(400).send('Invalid password');

  // Generate JWT token
  const token = jwt.sign({ id: user._id, role: user.role }, SECRET_KEY, { expiresIn: '7d' });

  // Return token and user info
  res.send({ token, userId: user._id, role: user.role });
});

// Middleware to authenticate token
const auth = (req, res, next) => {
  const token = req.header('Authorization').replace('Bearer ', '');
  console.log('Received Token:', token); // Debugging step
  try {
    const decoded = jwt.verify(token, SECRET_KEY);
    req.user = decoded;
    next();
  } catch (error) {
    console.error('Authorization Error:', error); // Debugging step
    res.status(401).send('Unauthorized');
  }
};

// Book Appointment
app.post('/appointments', auth, async (req, res) => {
  const { name, email, date, desc } = req.body;

  // Logging the request body to verify contents
  console.log('Request Body:', req.body);

  // Validation for the 'desc' field
  if (!desc) {
    return res.status(400).send('Description is required');
  }

  const appointment = new Appointment({ userId: req.user.id, name, email, date, desc });
  await appointment.save();
  res.send(appointment);
});

// Get User Appointments
// Get User Appointments
app.get('/appointments', auth, async (req, res) => {
  try {
    const appointments = await Appointment.find({ userId: req.user.id });
    console.log('Appointments:', appointments); // Log fetched appointments
    res.send(appointments);
  } catch (error) {
    console.error('Error fetching appointments:', error);
    res.status(500).send('Internal Server Error');
  }
});



app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
