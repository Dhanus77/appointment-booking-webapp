// src/pages/LoginPage.js
import React, { useState,useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import './css/LoginPage.css'; // Import custom CSS file
import axios from 'axios'
const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();
  const { token } = useContext(AuthContext);
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post('http://localhost:5000/login', { email, password });
      const { userId, role, token } = res.data; // Extract token from response
      localStorage.setItem('userId', userId);
      localStorage.setItem('role', role);
      localStorage.setItem('token', token); // Set token in local storage
      if (role === 'doctor') {
        navigate('/appointment');
      } else {
        navigate('/home');
      }
    } catch (error) {
      console.error('Login failed', error);
      setErrorMessage('Login failed. Please check the credentials.');
    }
  };
  


  return (
    <div className="login-container">
      <div className="login-form">
        <h2 className="mb-4">Login</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
            
              type="email"
              className="form-control"
              id="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
            
              type="password"
              className="form-control"
              id="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {errorMessage && <p className="error-message" style={{color:"red"}}>{errorMessage}</p>}
          <button type="submit" className="btn btn-primary btn-block" style={{marginLeft:"140px"}}>Login</button>
        </form>
        <div className="mt-3">
          <p className="mb-0">Don't have an account? <Link to="/register">Register here</Link></p>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
