import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import './css/AppointmentList.css'; // Import custom CSS file

const AppointmentList = () => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const { token } = useContext(AuthContext);

  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        const res = await axios.get('http://localhost:5000/appointments', {
          headers: { Authorization: `Bearer ${token}` },
        });
        console.log('API response:', res.data); // Log response from server
        setAppointments(res.data);
      } catch (error) {
        console.error('Error fetching appointments:', error.message); // Log error message
        setError('Error fetching appointments');
      } finally {
        setLoading(false);
      }
    };

    fetchAppointments();
  }, [token]);

  return (
    <div className="appointment-list-container">
      <h1 className="mb-4">Appointments</h1>
      {loading && <p>Loading...</p>}
      {error && <p className="error-message">{error}</p>}
      {!loading && !error && (
        <ul className="appointment-list">
          {appointments.map((appointment) => (
            <li key={appointment._id} className="appointment-item">
              <div>
                <span className="appointment-name">{appointment.name}</span> -{' '}
                <span className="appointment-date">{new Date(appointment.date).toLocaleString()}</span>-{' '}
                <span className="appointment-desc">{appointment.desc}</span> -{' '}
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AppointmentList;
