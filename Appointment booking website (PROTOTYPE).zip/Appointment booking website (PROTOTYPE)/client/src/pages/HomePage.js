// src/pages/HomePage.js
import React from 'react';
import { Link } from 'react-router-dom';
import './css/Homepage.css'; // Import custom CSS file

const HomePage = () => {
  return (
    <div className="container">
      <h1>Welcome to ABC Appointment Booking System</h1>
      <p>At ABC, we understand the importance of managing your appointments efficiently. Our appointment booking system is designed to simplify the process, allowing you to schedule appointments with ease.</p>


      <h2>Services Offered:</h2>
      <ul>
        <li><strong>Medical Appointments:</strong> Schedule appointments with healthcare providers, including doctors, specialists, and clinics.</li>
        <li><strong>Professional Services:</strong> Arrange meetings with lawyers, consultants, and other professionals.</li>
      </ul>

      <h2>Why Choose ABC Appointment Booking System?</h2>
      <ul>
        <li><strong>Save Time:</strong> Say goodbye to long wait times and phone calls. With our system, booking appointments takes just a few clicks.</li>
        <li><strong>Stay Organized:</strong> Keep track of all your appointments in one convenient location. Receive reminders and notifications to ensure you never miss an appointment.</li>
        <li><strong>Convenient Access:</strong> Access your appointments from any device, whether you're at home, in the office, or on the go.</li>
      </ul>

      <p>Ready to experience the convenience of our appointment booking system? Click the button below to book your appointment now!</p>
      <div>
      <Link to="/dashboard" className="btn btn-primary">Book Appointment</Link> 
      </div>
      <p>If you have any questions or need assistance, feel free to contact our support team at <a href="mailto:support@abc.com">support@abc.com</a>.</p>
    </div>
  );
};

export default HomePage;
