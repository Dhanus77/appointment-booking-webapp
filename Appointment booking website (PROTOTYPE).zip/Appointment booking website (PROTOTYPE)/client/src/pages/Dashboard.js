// src/pages/Dashboard.js
import React from 'react';
import BookingPage from './BookingPage';
import AppointmentList from './AppointmentList';

const Dashboard = () => (
  <div>
    <h1></h1>
    <BookingPage />
    
  </div>
);

export default Dashboard;
