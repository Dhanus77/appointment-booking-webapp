// src/pages/BookingPage.js
import React, { useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import './css/BookingPage.css'; // Import custom CSS file
import { useNavigate } from 'react-router-dom';

const BookingPage = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [date, setDate] = useState('');
  const [desc, setDesc] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const { token } = useContext(AuthContext);
  const navigate = useNavigate(); 
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/appointments', { name, email, date,desc}, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setName('');
      setEmail('');
      setDate('');
      setDesc('');
      setSuccessMessage('Appointment booked successfully!');
      setErrorMessage('');
      navigate('/home');
    } catch (error) {
      console.error('Booking failed', error);
      setErrorMessage('Booking failed. Please try again.');
      setSuccessMessage('');
    }
  };

  return (
    <div className="booking-container">
      <h1>Book Appointment</h1>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <input
            type="text"
            className="form-control"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <input
            type="email"
            className="form-control"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <input
            type="datetime-local"
            className="form-control"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            className="form-control"
            placeholder="Description"
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            required
          />
        </div>
        {successMessage && <p className="success-message">{successMessage}</p>}
        {errorMessage && <p className="error-message">{errorMessage}</p>}
        <button type="submit" className="btn btn-primary">Book</button>
      </form>
    </div>
  );
};

export default BookingPage;
